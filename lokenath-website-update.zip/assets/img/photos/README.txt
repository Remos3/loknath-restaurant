PUT YOUR OWN PHOTOS IN THIS FOLDER
==================================
Use exactly these file names (all lowercase, .jpg):

  hero.jpg       square photo for the top of the homepage   (1200 x 1200 px)
  biriyani.jpg   biriyani                                    (1200 x 900 px)
  thali.jpg      rice meal / thali                           (1200 x 900 px)
  momo.jpg       momo                                        (1200 x 900 px)
  chawmein.jpg   chawmein / fried rice                       (1200 x 900 px)
  rolls.jpg      rolls / burger / snacks                     (1200 x 900 px)
  drinks.jpg     coffee / shake / chat / soup                (1200 x 900 px)
  delivery.jpg   home delivery (scooter or packed order)     (1200 x 900 px)

If a photo is missing, the site shows a drawn illustration there instead.
Keep every photo under about 300 KB (shrink it first, see the instructions).
